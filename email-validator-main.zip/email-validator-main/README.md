# email-validator-html-css-js
 This project can be used to validate emails using the emailvalidation api
